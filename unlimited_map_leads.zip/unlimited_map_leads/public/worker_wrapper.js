try {
    importScripts("js/background.js", "js/helper.js", "js/services.js", "js/vendor.js");
} catch (e) {
    console.log(e);
}