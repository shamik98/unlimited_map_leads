//let $ = jQuery = require('jquery');
const makeApiRequest = function (methodType, dataToSend, sendToUrl, headers) {
  let head = {
    Accept: "application/json",
    "Content-Type": "application/json",
  };

  if (Object.keys(headers).length !== 0 && headers.constructor === Object) {
    head = headers;
    head["Content-Type"] = "application/json";
    head["Access-Control-Allow-Origin"] = "*";
  }

  if (sendToUrl.search("zapier") > 0) {
    head = {};
  }

  switch (methodType) {
    case "GET":
      var options = {
        method: methodType,
        headers: head,
      };
      break;
    default:
      var options = {
        method: methodType,
        body: JSON.stringify(dataToSend),
        headers: head,
      };
      break;
  }

  console.log("options :: ", JSON.stringify(options, null, 4));

    return new Promise((resolve) => {

      fetch(sendToUrl, options)
        .then((res) => res.json())
        .then((data) => {
          console.log("data :: ", JSON.stringify(data, null, 4));
          resolve(data);
        });
    });

  // return new Promise((resolve) => {
  //   $.ajax({
  //     url: sendToUrl,
  //     type: methodType,
  //     data: dataToSend,
  //     success: (response) => {
  //       resolve(response);
  //     },
  //     error: (e) => {
  //       resolve({
  //         status: false,
  //         message: "Please check your request and retry.",
  //       });
  //     },
  //   });
  // });

};

module.exports = {
  makeApiRequest: makeApiRequest,
};
