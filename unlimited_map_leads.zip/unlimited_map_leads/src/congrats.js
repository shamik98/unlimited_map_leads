//var $ = jQuery = require('jquery');
// const helper = require("./helper.js");

$(document).ready(function(){
    
  $("#homeBtnn").click(function(){
    console.log("dashboard....");
    chrome.storage.local.set({popupState: "dashboard"});
    chrome.runtime.sendMessage({msg : "clearBadge"});
    window.location.href = "../dashboard.html";
  })

});