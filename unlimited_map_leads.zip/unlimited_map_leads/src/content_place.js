//let $ = jQuery = require('jquery');
const states = require("./states.json");
const testDataJson = require("./testData.json");
const services = require("./services.js");
const api_cofig = require("./config.json");
const kyubiConfig = require('../public/kyubiSettings.json');

require("jquery-toast-plugin");

$(document).ready(function() {

    let csvExportRequired = false;

    let resultPickCount = 0,
        // startpos = 0,   shamik
        TotalCount = 0,
        resultRowCount = 1,
        searchPosition = 0,
        b,
        searchKey = "",
        storeInfoPost = [],
        customTimeOut = "",
        nextPageTimeout = "",
        get_hunter_data = "",
        get_tomba_data = "",
        domain_name = "",
        hunter_key = "",
        tomba_key = "",
        tomba_secret_key = "";

    let url = location.href.split('/');
    if ((url[2] == 'www.google.com' || url[2] == 'www.google.co.in') && url[3] == 'maps' && url[4] == 'search' && !url[3].split('?')[1]) {
        $.toast({
            text: kyubiConfig.appName + " has access to this page. Do you wanna get leads now?", // Text that is to be shown in the toast
            heading: 'Get your leads now!', // Optional heading to be shown on the toast
            icon: 'info', // Type of toast icon
            showHideTransition: 'fade', // fade, slide or plain
            allowToastClose: true, // Boolean value true or false
            hideAfter: false, // false to make it sticky or number representing the miliseconds as time after which toast needs to be hidden
            stack: false, // false if there should be only one toast at a time or a number representing the maximum number of toasts to be shown at a time
            position: 'top-center', // bottom-left or bottom-right or bottom-center or top-left or top-right or top-center or mid-center or an object representing the left, right, top, bottom values
            textAlign: 'left',  // Text alignment i.e. left, right or center
            loader: true,  // Whether to show loader or not. True by default
            loaderBg: '#9EC600',  // Background color of the toast loader
            bgColor: '#33691e',
            textColor : '#fff'
        });
    }

    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
        switch ( request.msg ) {
            case "start":
                loadAllData(request.formData);
                break;
            case "stop":
                stopScraping(request.formData);
                break;
            case "sendTestData":
                sendTestDataToWebhook(request.formData.url);
                break;
            case "hunter_details":
                get_hunter_data = request.hunter_data.get_hunter_data;
                hunter_key = request.hunter_data.hunter_key;
                break;
            case "tomba_details":
                get_tomba_data = request.tomba_data.get_tomba_data;
                tomba_key = request.tomba_data.tomba_key;
                tomba_secret_key = request.tomba_data.tomba_secret_key;
                break;
            default:
                break;
        }
    });

    function scrollToBottom() {
      var div = document.querySelectorAll('div[aria-label^="Results for"]')[0];
      div.scrollTop = div.scrollHeight - div.clientHeight;
    }

    function scrollToTop() {
      var div = document.querySelectorAll('div[aria-label^="Results for"]')[0];
      div.scrollTop = 0;
    }

    function loadAllData(data) {
        let loadAllDataInterval = setInterval(function () {
          if($("span").filter(function() { return $(this).text() === "You've reached the end of the list."; }).length) {
            clearInterval(loadAllDataInterval);
            scrollToTop();
            startScrapping(data);
          } else {
            scrollToBottom();
          }
        }, 5000);
    }    

    function startScrapping( data ){
        
        searchKey = $("#searchboxinput").val();

        if (
          document.querySelectorAll('button[role="checkbox"]')[0].ariaChecked ==
          "true"
        ) {
          document.querySelectorAll('button[role="checkbox"]')[0].click();
        }

        searchPosition = 1;

        resultRowCount = document.querySelectorAll('a[class="hfpxzc"]').length;
        b = document.querySelectorAll('a[class="hfpxzc"]');

        picData(0, data);
        
    }

    function stopScraping() {
        
        TotalCount = 0;

        clearTimeout(customTimeOut);
        clearTimeout(nextPageTimeout);
        
        if ( csvExportRequired ) {
            exportCsv();
            chrome.runtime.sendMessage({msg : "Complete"});
        } else {
            chrome.runtime.sendMessage({msg : "Complete"});
        }
    }

    // this method is gonna send a test data
    // depending upon hunter data option selected it'll send different test data
    function sendTestDataToWebhook ( webhookUrl ) {

        services.makeApiRequest('POST', ((get_hunter_data && hunter_key) || (get_tomba_data && tomba_key && tomba_secret_key)) ? testDataJson.with_email_data : testDataJson.without_email_data, webhookUrl, {})
            .then(info => {
                if ( info.status == false ){
                    chrome.runtime.sendMessage({msg : "error"});
                }  else {
                    chrome.runtime.sendMessage({msg : "success"});
                }
            })
            .catch(err => {
                console.log("err :: ", JSON.stringify(err, null, 4));
            });
    }

    function nextPage( dataProcessType ) {

        let nextPage = document.querySelectorAll('button[aria-label=" Next page "]') !== undefined ? document.querySelectorAll('button[aria-label=" Next page "]') : document.querySelectorAll('button[aria-label="Next page"]');

        if ( !nextPage.length) {

            clearTimeout(customTimeOut);
            clearTimeout(nextPageTimeout);

            if (csvExportRequired) {
                exportCsv();
                chrome.runtime.sendMessage({msg : "Complete"});
            } else {
                chrome.runtime.sendMessage({msg : "Complete"});
            }
        } else {

            nextClicked = true;
            nextPage[0].click();

            nextPageTimeout = setTimeout(() => {

                loadAllData();

                setTimeout(() => {
                    resultRowCount =
                      document.querySelectorAll('a[class="hfpxzc"]').length;
                    b = document.querySelectorAll('a[class="hfpxzc"]');

                    nextClicked = false;
                    resultPickCount = 0;
                    startpos = 0;

                    picData(startpos, dataProcessType);
                }, 5000);  //shamik//
                
            }, 5000);
        }
    }    

    function playWithDataWhenReady ( dataProcessType, businessInfoPost ) {
        if ( dataProcessType.how_proceed == 'csv' ) {
            // resultPickCount++;    shamik
            // startpos++;           shamik
            // TotalCount++;         shamik
            storeInfoPost.push(businessInfoPost);

            csvExportRequired = true;
            
            chrome.runtime.sendMessage({type: "setCount", count: TotalCount});

            // dataPickStatus = true;                   shamik

            // picData(startpos, dataProcessType);      shamik
            
        } else {
            services.makeApiRequest('POST', businessInfoPost, dataProcessType.url, {})
                .then(info => {

                    if ( info.status || info == "Accepted" ) {
                        csvExportRequired = false;
                        // resultPickCount++;         shamik
                        // startpos++;                shamik
                        // TotalCount++;              shamik

                        chrome.runtime.sendMessage({type: "setCount", count: TotalCount});

                        // dataPickStatus = true;           shamik

                        // picData(startpos, dataProcessType);      shamik
                    }
                                        
                })
                .catch(err => {
                    console.log("err :: ", JSON.stringify(err, null, 4));
                    resolve ({success : false});
                });

        }
    }

    function sendMessagePromise(item) {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage(item, response => {
                if(response.emails.length) {
                    resolve({status: true, emails: response.emails});
                } else {
                    resolve({status: false});
                }
            });
        });
    }

  function picData(startpos = 0, dataProcessType) {             ////(shamik)///del = 0

        if ( startpos < resultRowCount && b[resultPickCount] !== undefined) {
            
            /* =================== RESULT LIST CLICK ==================== */
            b[resultPickCount].click();

            customTimeOut = setTimeout(() => {
              /* =================== AFTER CLICK ==================== */
              dataPickStatus = false;

              let businessInfoPost = {};

              /* ======================== Search Position ========================= */
  
              if (
                $(b[resultPickCount]).parent().find("span.jHLihd").text().toLowerCase().trim() !== "ad"
                 ||
                $(b[resultPickCount]).parent().find("button[aria-label='Ad .']").length == 1
              ) {
                businessInfoPost.a_searchPosition = searchPosition++;
                businessInfoPost.b_adStatus = "No Ad";
              } else{
                businessInfoPost.a_searchPosition = "N/A";
                businessInfoPost.b_adStatus = "Ad";
              }

              /* ======================================================= */

              /* ======================== Name ========================= */

              businessInfoPost.c_name = document
                .querySelectorAll('div[role="main"]')[1]
                .ariaLabel.replace(/\,/g, "");

              // businessInfoPost.c_name = document.querySelectorAll('[class="DUwDvf fontHeadlineLarge"]')[0].innerText.replace(/,/g, "");



              /* ======================================================= */

              /* ======================== Description ========================= */
              let desc = document
                .querySelectorAll('button[jsaction = "pane.rating.category"]')[0]
                .innerText.replace(/(\r\n|\n|\r)/gm, "");

              if (desc == undefined || desc == "") {
                businessInfoPost.d_description = "N/A";
              } else {
                businessInfoPost.d_description = desc;
              }
              /* ======================================================= */

              /* ======================== Rating ========================= */
              // let rating = document.querySelectorAll(
              //   'div[jsaction = "pane.rating.moreReviews"]'
              // ).length ? document.querySelectorAll(
              //   'div[jsaction = "pane.rating.moreReviews"]'
              // )[0].children[0].innerText : "";

              // let rating = document.querySelectorAll('.ceNzKf')[0].ariaLabel.replace(/stars/g, '');


              // if (rating == undefined || rating == "") {
              //   businessInfoPost.e_rating = "N/A";
              // } else {
              //   businessInfoPost.e_rating = rating;
              // }

              let rating = document.querySelectorAll('.ceNzKf')[0];
              if (rating == undefined || rating == "") {
                businessInfoPost.e_rating = "N/A";
              } else {
                businessInfoPost.e_rating = document.querySelectorAll('.ceNzKf')[0].ariaLabel.replace(/stars/g, '');
              }

              /* ======================================================= */

              /* ======================== Reviews ========================= */        
              // let review = document.querySelectorAll(
              //   'button[jsaction = "pane.rating.moreReviews"]'
              // )[0] ? document.querySelectorAll(
              //   'button[jsaction = "pane.rating.moreReviews"]'
              // )[0].innerText : "";

              //let review = 
              // document.querySelector('.F7nice.mmu3tf').getElementsByTagName('span') ?
              // document.querySelector('.F7nice.mmu3tf').getElementsByTagName('span')[10].jsan = "0.aria-label" : "";



              // let review = document.querySelectorAll(
              //   'div[jsaction = "pane.rating.moreReviews"]'
              // ).length ? document.querySelectorAll(
              //   'div[jsaction = "pane.rating.moreReviews"]'
              // )[0].children[1].innerText : "";


              
              let review = document.querySelectorAll('.F7nice')[0].getElementsByTagName('span')[10];



              // let review = document.querySelectorAll('.F7nice')[0].getElementsByTagName('span')[10].ariaLabel.replace(/ reviews/g, '').replace(/,/g, '');



              // if (review == undefined || review == "") {
              //   businessInfoPost.f_reviews = "N/A";
              // } else {
              //   businessInfoPost.f_reviews = review
              //   .split(" ")[0]
              //   //  .replace(/\,/g, "");
              // }

              if (review == undefined || review == "") {
                businessInfoPost.f_reviews = "N/A";
              } else {
                businessInfoPost.f_reviews = document.querySelectorAll('.F7nice')[0].getElementsByTagName('span')[10].ariaLabel.replace(/ reviews/g, '').replace(/,/g, '').split(" ")[0]
              }


              
              /* ======================================================= */

              /* ======================== Phone ========================= */

              let phone = document.querySelectorAll(
                'button[data-tooltip="Copy phone number"]'
              )[0]
                ? document
                    .querySelectorAll(
                      'button[data-tooltip="Copy phone number"]'
                    )[0]
                    .innerText.replace(/\D/g, "")
                : "";

              if (phone == undefined || phone == "") {
                businessInfoPost.g_phone = "N/A";
              } else {
                businessInfoPost.g_phone = phone;
              }

              /* ======================================================= */

              /* ======================== Address ========================= */
              let address = document.querySelectorAll(
                'button[data-item-id="address"]'
              )[0]
                ? document.querySelectorAll('button[data-item-id="address"]')[0]
                    .innerText
                : "";

              let foundUAE = address.search("United Arab Emirates");

              let addressLength = address.split(",").length;
              let addressPropSplit = address.split(",")[addressLength - 2];

              if (address == undefined || address == "") {
                businessInfoPost.h_streetAddress = "N/A";
                businessInfoPost.i_city = "N/A";
                businessInfoPost.j_state = "N/A";
                businessInfoPost.k_zip = "N/A";
              } else if (
                foundUAE < 0 &&
                states[addressPropSplit.split(" ")[1]] !== undefined
              ) {
                let stAddress = "";
                for (let i = 0; i <= addressLength - 4; i++) {
                  if (i > 0) {
                    stAddress += ", " + address.split(",")[i];
                  } else {
                    stAddress = address.split(",")[i];
                  }
                }

                businessInfoPost.h_streetAddress = stAddress.replace(
                  /\,/g,
                  " "
                );

                businessInfoPost.i_city =
                  addressPropSplit.split(" ")[1] == "DC"
                    ? "Washington D.C."
                    : address.split(",")[addressLength - 3];
                businessInfoPost.j_state =
                  addressPropSplit.split(" ")[1] == "DC"
                    ? "Washington D.C."
                    : states[addressPropSplit.split(" ")[1]];

                businessInfoPost.k_zip = address
                  .split(",")
                  [addressLength - 2].split(" ")[2];
              } else if (foundUAE > 0) {
                addressPropSplit = address.split(" - ");
                addressLength = addressPropSplit.length;
                let stAddress = "";
                for (let i = 0; i <= addressLength - 3; i++) {
                  if (i > 0) {
                    stAddress += ", " + addressPropSplit[i];
                  } else {
                    stAddress = addressPropSplit[i];
                  }
                }

                businessInfoPost.h_streetAddress = stAddress.replace(
                  /\,/g,
                  " "
                );

                businessInfoPost.i_city = addressPropSplit[addressLength - 2];
                businessInfoPost.j_state = "N/A";
                businessInfoPost.k_zip = "N/A";
              } else {
                businessInfoPost.h_streetAddress = address.replace(/\,/g, "");
                businessInfoPost.i_city = "N/A";
                businessInfoPost.j_state = "N/A";
                businessInfoPost.k_zip = "N/A";
              }
              /* ======================================================= */

              /* ======================== Website ========================= */

              let website = document.querySelectorAll(
                'a[data-tooltip="Open website"]'
              )[0]
                ? document.querySelectorAll(
                    'a[data-tooltip="Open website"]'
                  )[0].innerText
                : "#";
              if (website == undefined || website == "" || website == "#") {
                businessInfoPost.l_website = "N/A";
              } else {
                businessInfoPost.l_website = website;
                domain_name = website
                  .replace("http://", "")
                  .replace("https://", "")
                  .split(/[/?#]/)[0];
              }
              /* ======================================================= */

              /* ========================= Email ======================= */

              // if (
              //   get_hunter_data &&
              //   hunter_key &&
              //   businessInfoPost.l_website !== "N/A"
              // ) {
              //   let url =
              //     api_cofig.hunter_api +
              //     "domain=" +
              //     domain_name +
              //     "&api_key=" +
              //     hunter_key;
              //   services.makeApiRequest("GET", "", url, {}).then((info) => {
              //     if (info.data.emails.length) {
              //       info.data.emails.forEach(function (element, index) {
              //         businessInfoPost["email_" + (index + 1)] = element.value;
              //         businessInfoPost["fname_" + (index + 1)] =
              //           element.first_name ? element.first_name : "";
              //         businessInfoPost["lname_" + (index + 1)] =
              //           element.last_name ? element.last_name : "";

              //         if (index == info.data.emails.length - 1) {
              //           playWithDataWhenReady(
              //             dataProcessType,
              //             businessInfoPost
              //           );
              //         }
              //       });
              //     } else {
              //       playWithDataWhenReady(dataProcessType, businessInfoPost);
              //     }
              //   });
              // } else if (
              //   get_tomba_data &&
              //   tomba_key &&
              //   tomba_secret_key &&
              //   businessInfoPost.l_website !== "N/A"
              // ) {
              //   sendMessagePromise({
              //     type: "getEmailDetails",
              //     domain: domain_name,
              //   }).then(function (res) {
              //     if (res.status) {
              //       res.emails.forEach(function (element, index) {
              //         businessInfoPost["email_" + (index + 1)] = element.email;
              //         businessInfoPost["fname_" + (index + 1)] =
              //           element.first_name ? element.first_name : "";
              //         businessInfoPost["lname_" + (index + 1)] =
              //           element.last_name ? element.last_name : "";

              //         if (index == res.emails.length - 1) {
              //           playWithDataWhenReady(
              //             dataProcessType,
              //             businessInfoPost
              //           );
              //         }
              //       });
              //     } else {
              //       playWithDataWhenReady(dataProcessType, businessInfoPost);
              //     }
              //   });
              // } else {
              //   playWithDataWhenReady(dataProcessType, businessInfoPost);
              // }


//new//


              if (get_hunter_data && hunter_key && businessInfoPost.l_website !== 'N/A') {

                sendMessagePromise({ type: "getHunterEmailDetails", domain: domain_name })
                  .then(function (info) {
                    // services.makeApiRequest('GET', '', url, {})
                    //     .then(info => {
                    if (info.status) {
                      info.emails.forEach(function (element, index) {
                        businessInfoPost['email_' + (index + 1)] = element.value;
                        businessInfoPost['fname_' + (index + 1)] = element.first_name ? element.first_name : '';
                        businessInfoPost['lname_' + (index + 1)] = element.last_name ? element.last_name : '';

                        if (index == info.emails.length - 1) {
                          playWithDataWhenReady(dataProcessType, businessInfoPost);
                        }
                      });
                    } else {
                      playWithDataWhenReady(dataProcessType, businessInfoPost);
                    }
                  });



                // let url =
                //   api_cofig.hunter_api +
                //   "domain=" +
                //   domain_name +
                //   "&api_key=" +
                //   hunter_key;
                // services.makeApiRequest("GET", "", url, {}).then((info) => {
                //   if (info.data.emails.length) {
                //     info.data.emails.forEach(function (element, index) {
                //       businessInfoPost["email_" + (index + 1)] = element.value;
                //       businessInfoPost["fname_" + (index + 1)] =
                //         element.first_name ? element.first_name : "";
                //       businessInfoPost["lname_" + (index + 1)] =
                //         element.last_name ? element.last_name : "";

                //       if (index == info.data.emails.length - 1) {
                //         playWithDataWhenReady(
                //           dataProcessType,
                //           businessInfoPost
                //         );
                //       }
                //     });
                //   } else {
                //     playWithDataWhenReady(dataProcessType, businessInfoPost);
                //   }
                // });



              } else if (get_tomba_data && tomba_key && tomba_secret_key && businessInfoPost.l_website !== 'N/A') {

                sendMessagePromise({ type: "getTombaEmailDetails", domain: domain_name })
                  .then(function (res) {
                    if (res.status) {
                      res.emails.forEach(function (element, index) {
                        businessInfoPost['email_' + (index + 1)] = element.email;
                        businessInfoPost['fname_' + (index + 1)] = element.first_name ? element.first_name : '';
                        businessInfoPost['lname_' + (index + 1)] = element.last_name ? element.last_name : '';

                        if (index == res.emails.length - 1) {
                          playWithDataWhenReady(dataProcessType, businessInfoPost);
                        }
                      });
                    } else {
                      playWithDataWhenReady(dataProcessType, businessInfoPost);
                    }
                  });
              } else {
                playWithDataWhenReady(dataProcessType, businessInfoPost);
              }



              ///////////////////////(shamik)del this part
              dataPickStatus = true;

              resultPickCount++;
              startpos++;
              TotalCount++;

              chrome.runtime.sendMessage({ type: "setCount", count: TotalCount });

              picData(startpos, dataProcessType);
                //////////////////////////

                


              /* ======================================================= */
            }, 2000);
        } else {

            setTimeout(function() {
                nextPage( dataProcessType );
            }, 2000);
            
        }
    }

    function exportCsv() {
        
        clearTimeout(customTimeOut);

        if (( get_hunter_data && hunter_key ) || ( get_tomba_data && tomba_key && tomba_secret_key )) {
            storeInfoPost.unshift(["Search Position", "Ad status", "Business name", "Description", "Rating", "Total reviews", "Phone number", "Street Address", "City", "State", "Zip", "Website", "email_1", "fname_1", "lname_1", "email_2", "fname_2", "lname_2", "email_3", "fname_3", "lname_3", "email_4", "fname_4", "lname_4", "email_5", "fname_5", "lname_5", "email_6", "fname_6", "lname_6", "email_7", "fname_7", "lname_7", "email_8", "fname_8", "lname_8", "email_9", "fname_9", "lname_9", "email_10", "fname_10", "lname_10"]);
        } else {
            storeInfoPost.unshift(["Search Position", "Ad status", "Business name", "Description", "Rating", "Total reviews", "Phone number", "Street Address", "City", "State", "Zip", "Website"]);
        }
        
        let jsonObject = JSON.stringify(storeInfoPost);
        var csv = ConvertToCSV(jsonObject);


        let blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
        if (navigator.msSaveBlob) {
            // IE 10+
            navigator.msSaveBlob(blob, searchKey);
        } else {
            let link = document.createElement("a");
            if (link.download !== undefined) {
                // feature detection
                // Browsers that support HTML5 download attribute
                let url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", searchKey + '.csv');
                link.style.visibility = "hidden";
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }
    }

    function ConvertToCSV(objArray) {

        var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
        var str = '';

        for (let i = 0; i < array.length; i++) {
            let line = "";
            for (let index in array[i]) {
                if (line !== "") line += ",";
                line += array[i][index];
            }
            str += line + "\r\n";
        }
        return str;

    }

});