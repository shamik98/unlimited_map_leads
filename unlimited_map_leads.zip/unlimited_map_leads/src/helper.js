const api_config = require("./config.json");
const kyubiConfig = require('../public/kyubiSettings.json');

const getAccessToken = function(res) {
    // //console.log("checkAccessToken running : ", res)
    return res !== null &&
        res !== undefined &&
        res.store !== null &&
        res.store !== undefined &&
        res.store.user !== null &&
        res.store.user !== undefined
        ? res.store.user.token
        : null;
}

const checkAccessToken = function(res) {
    const token = getAccessToken(res)
    // //console.log("helper -- checkAccessToken running : ", token)
    if(token !== null && token !== undefined && token.length > 0) {
        return true
    }
    return false
}


const doAuthCheck = function(accessToken) {
  // //console.log("accessToken:  do auth working : ", accessToken)
  if (
    accessToken !== undefined &&
    accessToken !== null &&
    accessToken.length > 0
  ) {
    return true;
  }
  return false;
}

const checkUserStatus = function(accessToken) {

  return new Promise(function(resolve, reject) {
    let data = {
      userToken: accessToken
    };

    let url = api_config.kyubi_base_url + api_config.check_status;

    services.makeApiRequest('POST', data, url, {})
      .then(info => {
          if (info.status) {
            resolve(true)
          } else {
            reject(false)
          }
      })
      .catch(err => {
        reject(false)
      });
  });
}

const getLoggedInUser = () => {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get("emailID", function(items) {
      resolve(items.emailID);
    });
  });
};


const checkAuthStatus = () => {
  // //console.log("Check authentication");
  chrome.storage.sync.get(['store'], function (res) {
  
  if (res.store.user.email != null || res.store.user.email != undefined || res.store.user.email != "") {
  
    // //console.log(res.store);
    // //console.log(res.store.user.email);
  
    fetch(authURL.BASE_URL + "end-user/get-status", {
        method: "POST", // *GET, POST, PUT, DELETE, etc.
        mode: "cors", // no-cors, cors, *same-origin
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          email: res.store.user.email, extId: kyubiConfig.extId
        }) // body data type must match "Content-Type" header
      })
      .then(response => response.json())
      .then(res => {
        const resp = (res.data)?res.data:res;
        // //console.log("Auth Status",res);
        if (resp.status === false) {
  
          chrome.storage.sync.remove(('store'), function () {
            window.location.href='../login.html'

          });
        }
      })
      .catch(err => {
        // //console.log(err.message);
  
      });
  } else {
    window.location.href='../login.html'
  
  }
  });
}  

module.exports = {
    checkAccessToken: checkAccessToken,
    getAccessToken: getAccessToken,
    doAuthCheck: doAuthCheck,
    getLoggedInUser: getLoggedInUser,
    checkUserStatus: checkUserStatus,
    checkAuthStatus: checkAuthStatus
};